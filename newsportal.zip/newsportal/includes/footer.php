    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; NewsPortal <?php echo date('Y');?></p>
      </div>
      <!-- /.container -->
    </footer>